import java.util.Scanner;

public class Question03EnglishLearningAssistant {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        char ch = sc.next().charAt(0);

        switch (Character.toLowerCase(ch)) {
            case 'a', 'e', 'i', 'o', 'u' -> System.out.println("Vowel");
            default -> {
                if (Character.isLetter(ch))
                    System.out.println("Consonant");
                else
                    System.out.println("Invalid character");
            }
        }
    }
}
