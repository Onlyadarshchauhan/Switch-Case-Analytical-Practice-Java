import java.util.Scanner;

public class Question08NavaRatnasFinalPosition {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();

        int x = 0;
        int y = 0;

        for (int i = 1; i <= n; i++) {
            int distance = i * 10;

            switch ((i - 1) % 4) {
                case 0 -> x += distance;
                case 1 -> y += distance;
                case 2 -> x -= distance;
                case 3 -> y -= distance;
            }
        }

        System.out.println(x + " " + y);
    }
}
