import java.util.Scanner;

public class Question06UnitConversionDesk {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int choice = sc.nextInt();
        double value = sc.nextDouble();

        switch (choice) {
            case 1 -> System.out.println((value * 9 / 5) + 32 + " F");
            case 2 -> System.out.println((value - 32) * 5 / 9 + " C");
            case 3 -> System.out.println(value * 1000 + " m");
            case 4 -> System.out.println(value / 1000 + " km");
            default -> System.out.println("Invalid choice");
        }
    }
}
