import java.util.Scanner;

public class Question04SmartTrafficSignal {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        char signal = Character.toUpperCase(sc.next().charAt(0));

        switch (signal) {
            case 'R' -> System.out.println("Stop");
            case 'Y' -> System.out.println("Wait");
            case 'G' -> System.out.println("Go");
            default -> System.out.println("Invalid signal");
        }
    }
}
