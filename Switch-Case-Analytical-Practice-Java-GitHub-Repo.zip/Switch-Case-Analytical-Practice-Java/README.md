# Switch-Case Analytical Practice Questions

Java solutions for all 8 questions from the provided Switch-Case Analytical Practice Questions sheet.

## Questions
1. Weekly Planner
2. Pocket Calculator
3. English Learning Assistant
4. Smart Traffic Signal
5. Architect's Shape Calculator
6. Unit Conversion Desk
7. Engineering Measurement Assistant
8. King Vikramaditya's Nava Ratnas - Final Position

## Run
```bash
javac Question01WeeklyPlanner.java
java Question01WeeklyPlanner
```

Replace the filename with the required question.
