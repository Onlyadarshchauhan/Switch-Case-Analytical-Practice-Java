import java.util.Scanner;

public class Question07EngineeringMeasurementAssistant {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int type = sc.nextInt();

        switch (type) {
            case 1 -> {
                int shape = sc.nextInt();

                switch (shape) {
                    case 1 -> {
                        double length = sc.nextDouble();
                        double width = sc.nextDouble();
                        System.out.println("Area = " + (length * width));
                    }
                    case 2 -> {
                        double radius = sc.nextDouble();
                        System.out.println("Area = " + (Math.PI * radius * radius));
                    }
                    case 3 -> {
                        double base = sc.nextDouble();
                        double height = sc.nextDouble();
                        System.out.println("Area = " + (0.5 * base * height));
                    }
                    default -> System.out.println("Invalid shape");
                }
            }
            case 2 -> {
                int solid = sc.nextInt();

                switch (solid) {
                    case 1 -> {
                        double radius = sc.nextDouble();
                        double height = sc.nextDouble();
                        System.out.println("Volume = " + (Math.PI * radius * radius * height / 3));
                    }
                    case 2 -> {
                        double length = sc.nextDouble();
                        double width = sc.nextDouble();
                        double height = sc.nextDouble();
                        System.out.println("Volume = " + (length * width * height));
                    }
                    case 3 -> {
                        double radius = sc.nextDouble();
                        System.out.println("Volume = " + (4.0 / 3 * Math.PI * radius * radius * radius));
                    }
                    default -> System.out.println("Invalid solid");
                }
            }
            default -> System.out.println("Invalid calculation type");
        }
    }
}
