import java.util.Scanner;

public class Question05ShapeCalculator {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String shape = sc.next().toLowerCase();
        double area;

        switch (shape) {
            case "circle" -> {
                double radius = sc.nextDouble();
                area = Math.PI * radius * radius;
                System.out.println("Circle");
                System.out.println("Area = " + area);
            }
            case "rectangle" -> {
                double length = sc.nextDouble();
                double width = sc.nextDouble();
                area = length * width;
                System.out.println("Rectangle");
                System.out.println("Area = " + area);
            }
            case "square" -> {
                double side = sc.nextDouble();
                area = side * side;
                System.out.println("Square");
                System.out.println("Area = " + area);
            }
            case "triangle" -> {
                double base = sc.nextDouble();
                double height = sc.nextDouble();
                area = 0.5 * base * height;
                System.out.println("Right-Angle Triangle");
                System.out.println("Area = " + area);
            }
            default -> System.out.println("Invalid shape");
        }
    }
}
