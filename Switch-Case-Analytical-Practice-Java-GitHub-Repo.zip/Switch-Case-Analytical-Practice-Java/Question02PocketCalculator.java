import java.util.Scanner;

public class Question02PocketCalculator {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double a = sc.nextDouble();
        double b = sc.nextDouble();
        char op = sc.next().charAt(0);

        switch (op) {
            case '+' -> System.out.println(a + b);
            case '-' -> System.out.println(a - b);
            case '*' -> System.out.println(a * b);
            case '/' -> {
                if (b == 0)
                    System.out.println("Cannot divide by zero");
                else
                    System.out.println(a / b);
            }
            default -> System.out.println("Invalid operator");
        }
    }
}
